﻿namespace Pacientes
{
    partial class FrmPacientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPacientes));
            this.label1 = new System.Windows.Forms.Label();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.combotipo = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbfemenino = new System.Windows.Forms.RadioButton();
            this.rdbmasculino = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.combocarrera = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboetnia = new System.Windows.Forms.ComboBox();
            this.txtaltura = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtpeso = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtemergencia = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txttelefono = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtbusqueda = new System.Windows.Forms.TextBox();
            this.datagridx = new System.Windows.Forms.DataGridView();
            this.codigo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtfechanac = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.combosangre = new System.Windows.Forms.ComboBox();
            this.comboap = new System.Windows.Forms.ComboBox();
            this.txtcodigo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.datagrida = new System.Windows.Forms.DataGridView();
            this.alergia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.datagridp = new System.Windows.Forms.DataGridView();
            this.padecimiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rbalergia = new System.Windows.Forms.RadioButton();
            this.rbpadecimiento = new System.Windows.Forms.RadioButton();
            this.btneliminar = new System.Windows.Forms.Button();
            this.btnagregar = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btn_salir = new System.Windows.Forms.Button();
            this.bteliminar = new System.Windows.Forms.Button();
            this.btn_cambios = new System.Windows.Forms.Button();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.btn_cancelar2 = new System.Windows.Forms.Button();
            this.btn_editar = new System.Windows.Forms.Button();
            this.btn_nuevo = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.rtxtobservacion = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridx)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrida)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridp)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre Completo:";
            // 
            // txtnombre
            // 
            this.txtnombre.Location = new System.Drawing.Point(125, 48);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.ReadOnly = true;
            this.txtnombre.Size = new System.Drawing.Size(250, 20);
            this.txtnombre.TabIndex = 1;
            this.txtnombre.TextChanged += new System.EventHandler(this.txtnombre_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Fecha de Nacimiento:";
            // 
            // combotipo
            // 
            this.combotipo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combotipo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combotipo.Enabled = false;
            this.combotipo.FormattingEnabled = true;
            this.combotipo.Items.AddRange(new object[] {
            "Catedratico",
            "Estudiante",
            "Visitante"});
            this.combotipo.Location = new System.Drawing.Point(125, 113);
            this.combotipo.Name = "combotipo";
            this.combotipo.Size = new System.Drawing.Size(250, 21);
            this.combotipo.TabIndex = 3;
            this.combotipo.SelectedIndexChanged += new System.EventHandler(this.combotipo_SelectedIndexChanged);
            this.combotipo.Leave += new System.EventHandler(this.combotipo_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbfemenino);
            this.groupBox1.Controls.Add(this.rdbmasculino);
            this.groupBox1.Location = new System.Drawing.Point(951, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(202, 57);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Genero";
            // 
            // rdbfemenino
            // 
            this.rdbfemenino.AutoSize = true;
            this.rdbfemenino.Enabled = false;
            this.rdbfemenino.Location = new System.Drawing.Point(117, 21);
            this.rdbfemenino.Name = "rdbfemenino";
            this.rdbfemenino.Size = new System.Drawing.Size(71, 17);
            this.rdbfemenino.TabIndex = 1;
            this.rdbfemenino.TabStop = true;
            this.rdbfemenino.Text = "Femenino";
            this.rdbfemenino.UseVisualStyleBackColor = true;
            this.rdbfemenino.CheckedChanged += new System.EventHandler(this.rdbfemenino_CheckedChanged);
            // 
            // rdbmasculino
            // 
            this.rdbmasculino.AutoSize = true;
            this.rdbmasculino.Enabled = false;
            this.rdbmasculino.Location = new System.Drawing.Point(21, 21);
            this.rdbmasculino.Name = "rdbmasculino";
            this.rdbmasculino.Size = new System.Drawing.Size(73, 17);
            this.rdbmasculino.TabIndex = 0;
            this.rdbmasculino.TabStop = true;
            this.rdbmasculino.Text = "Masculino";
            this.rdbmasculino.UseVisualStyleBackColor = true;
            this.rdbmasculino.CheckedChanged += new System.EventHandler(this.rdbmasculino_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tipo de Paciente:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(75, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Carrera:";
            // 
            // combocarrera
            // 
            this.combocarrera.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combocarrera.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combocarrera.Enabled = false;
            this.combocarrera.FormattingEnabled = true;
            this.combocarrera.Location = new System.Drawing.Point(125, 146);
            this.combocarrera.Name = "combocarrera";
            this.combocarrera.Size = new System.Drawing.Size(250, 21);
            this.combocarrera.TabIndex = 4;
            this.combocarrera.Leave += new System.EventHandler(this.combocarrera_Leave);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboetnia);
            this.groupBox2.Controls.Add(this.txtaltura);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtpeso);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(877, 95);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(393, 89);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Descripcion Fisica";
            // 
            // comboetnia
            // 
            this.comboetnia.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboetnia.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboetnia.Enabled = false;
            this.comboetnia.Items.AddRange(new object[] {
            "Caucasica",
            "Mongoloide ",
            "Negroide"});
            this.comboetnia.Location = new System.Drawing.Point(74, 58);
            this.comboetnia.Name = "comboetnia";
            this.comboetnia.Size = new System.Drawing.Size(280, 21);
            this.comboetnia.TabIndex = 2;
            this.comboetnia.Leave += new System.EventHandler(this.comboetnia_Leave);
            // 
            // txtaltura
            // 
            this.txtaltura.Location = new System.Drawing.Point(247, 25);
            this.txtaltura.Name = "txtaltura";
            this.txtaltura.ReadOnly = true;
            this.txtaltura.Size = new System.Drawing.Size(107, 20);
            this.txtaltura.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(33, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "Etnia:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(201, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Altura:";
            // 
            // txtpeso
            // 
            this.txtpeso.Location = new System.Drawing.Point(74, 26);
            this.txtpeso.Name = "txtpeso";
            this.txtpeso.ReadOnly = true;
            this.txtpeso.Size = new System.Drawing.Size(114, 20);
            this.txtpeso.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Peso:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtemergencia);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.txtemail);
            this.groupBox3.Controls.Add(this.txttelefono);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Location = new System.Drawing.Point(877, 214);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(393, 123);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Contacto";
            // 
            // txtemergencia
            // 
            this.txtemergencia.Location = new System.Drawing.Point(141, 53);
            this.txtemergencia.Name = "txtemergencia";
            this.txtemergencia.ReadOnly = true;
            this.txtemergencia.Size = new System.Drawing.Size(213, 20);
            this.txtemergencia.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(23, 58);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(117, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Telefono (Emergencia):";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(141, 81);
            this.txtemail.Name = "txtemail";
            this.txtemail.ReadOnly = true;
            this.txtemail.Size = new System.Drawing.Size(213, 20);
            this.txtemail.TabIndex = 2;
            // 
            // txttelefono
            // 
            this.txttelefono.Location = new System.Drawing.Point(141, 23);
            this.txttelefono.Name = "txttelefono";
            this.txttelefono.ReadOnly = true;
            this.txttelefono.Size = new System.Drawing.Size(213, 20);
            this.txttelefono.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(83, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "E-Mail:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(83, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Telefono:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtbusqueda);
            this.groupBox4.Location = new System.Drawing.Point(12, 13);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(434, 54);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Busqueda";
            // 
            // txtbusqueda
            // 
            this.txtbusqueda.Location = new System.Drawing.Point(6, 19);
            this.txtbusqueda.Name = "txtbusqueda";
            this.txtbusqueda.Size = new System.Drawing.Size(422, 20);
            this.txtbusqueda.TabIndex = 0;
            this.txtbusqueda.TextChanged += new System.EventHandler(this.txtbusqueda_TextChanged);
            // 
            // datagridx
            // 
            this.datagridx.AllowUserToAddRows = false;
            this.datagridx.AllowUserToDeleteRows = false;
            this.datagridx.AllowUserToResizeColumns = false;
            this.datagridx.AllowUserToResizeRows = false;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridx.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.datagridx.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridx.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.codigo,
            this.Nombre});
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridx.DefaultCellStyle = dataGridViewCellStyle20;
            this.datagridx.Location = new System.Drawing.Point(12, 73);
            this.datagridx.MultiSelect = false;
            this.datagridx.Name = "datagridx";
            this.datagridx.ReadOnly = true;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridx.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.datagridx.Size = new System.Drawing.Size(434, 358);
            this.datagridx.TabIndex = 0;
            this.datagridx.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridx_CellContentClick);
            // 
            // codigo
            // 
            this.codigo.HeaderText = "Codigo";
            this.codigo.Name = "codigo";
            this.codigo.ReadOnly = true;
            this.codigo.Width = 150;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.ReadOnly = true;
            this.Nombre.Width = 241;
            // 
            // dtfechanac
            // 
            this.dtfechanac.CustomFormat = "31/08/1900";
            this.dtfechanac.Enabled = false;
            this.dtfechanac.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtfechanac.Location = new System.Drawing.Point(125, 78);
            this.dtfechanac.Name = "dtfechanac";
            this.dtfechanac.Size = new System.Drawing.Size(85, 20);
            this.dtfechanac.TabIndex = 1;
            this.dtfechanac.Value = new System.DateTime(2017, 8, 22, 0, 0, 0, 0);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(220, 80);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Tipo de Sangre:";
            // 
            // combosangre
            // 
            this.combosangre.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combosangre.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combosangre.Enabled = false;
            this.combosangre.FormattingEnabled = true;
            this.combosangre.Items.AddRange(new object[] {
            "AB+",
            "AB-",
            "A+",
            "A-",
            "B+",
            "B-",
            "O+",
            "O-"});
            this.combosangre.Location = new System.Drawing.Point(303, 77);
            this.combosangre.Name = "combosangre";
            this.combosangre.Size = new System.Drawing.Size(72, 21);
            this.combosangre.TabIndex = 2;
            this.combosangre.Leave += new System.EventHandler(this.combosangre_Leave);
            // 
            // comboap
            // 
            this.comboap.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboap.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboap.Enabled = false;
            this.comboap.FormattingEnabled = true;
            this.comboap.Location = new System.Drawing.Point(11, 23);
            this.comboap.Name = "comboap";
            this.comboap.Size = new System.Drawing.Size(205, 21);
            this.comboap.TabIndex = 0;
            this.comboap.Leave += new System.EventHandler(this.comboap_Leave);
            // 
            // txtcodigo
            // 
            this.txtcodigo.Location = new System.Drawing.Point(125, 18);
            this.txtcodigo.Name = "txtcodigo";
            this.txtcodigo.ReadOnly = true;
            this.txtcodigo.Size = new System.Drawing.Size(250, 20);
            this.txtcodigo.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(77, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Codigo:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.datagrida);
            this.groupBox5.Location = new System.Drawing.Point(461, 343);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(393, 298);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Alergias";
            // 
            // datagrida
            // 
            this.datagrida.AllowUserToAddRows = false;
            this.datagrida.AllowUserToDeleteRows = false;
            this.datagrida.AllowUserToResizeColumns = false;
            this.datagrida.AllowUserToResizeRows = false;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagrida.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.datagrida.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrida.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.alergia});
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagrida.DefaultCellStyle = dataGridViewCellStyle23;
            this.datagrida.Location = new System.Drawing.Point(6, 19);
            this.datagrida.MultiSelect = false;
            this.datagrida.Name = "datagrida";
            this.datagrida.ReadOnly = true;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagrida.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.datagrida.Size = new System.Drawing.Size(381, 273);
            this.datagrida.TabIndex = 0;
            this.datagrida.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagrida_CellContentClick);
            // 
            // alergia
            // 
            this.alergia.HeaderText = "Alergia";
            this.alergia.Name = "alergia";
            this.alergia.ReadOnly = true;
            this.alergia.Width = 338;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.datagridp);
            this.groupBox6.Location = new System.Drawing.Point(877, 343);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(393, 298);
            this.groupBox6.TabIndex = 19;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Padecimientos";
            // 
            // datagridp
            // 
            this.datagridp.AllowUserToAddRows = false;
            this.datagridp.AllowUserToDeleteRows = false;
            this.datagridp.AllowUserToResizeColumns = false;
            this.datagridp.AllowUserToResizeRows = false;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridp.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.datagridp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.padecimiento});
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridp.DefaultCellStyle = dataGridViewCellStyle26;
            this.datagridp.Location = new System.Drawing.Point(6, 19);
            this.datagridp.MultiSelect = false;
            this.datagridp.Name = "datagridp";
            this.datagridp.ReadOnly = true;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridp.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.datagridp.Size = new System.Drawing.Size(381, 273);
            this.datagridp.TabIndex = 0;
            this.datagridp.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridp_CellContentClick);
            // 
            // padecimiento
            // 
            this.padecimiento.HeaderText = "Padecimiento";
            this.padecimiento.Name = "padecimiento";
            this.padecimiento.ReadOnly = true;
            this.padecimiento.Width = 338;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rbalergia);
            this.groupBox7.Controls.Add(this.rbpadecimiento);
            this.groupBox7.Controls.Add(this.comboap);
            this.groupBox7.Controls.Add(this.btneliminar);
            this.groupBox7.Controls.Add(this.btnagregar);
            this.groupBox7.Location = new System.Drawing.Point(461, 214);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(393, 123);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Control de Alergia/Padecimientos";
            // 
            // rbalergia
            // 
            this.rbalergia.AutoSize = true;
            this.rbalergia.Enabled = false;
            this.rbalergia.Location = new System.Drawing.Point(78, 54);
            this.rbalergia.Name = "rbalergia";
            this.rbalergia.Size = new System.Drawing.Size(62, 17);
            this.rbalergia.TabIndex = 1;
            this.rbalergia.TabStop = true;
            this.rbalergia.Text = "Alergias";
            this.rbalergia.UseVisualStyleBackColor = true;
            this.rbalergia.CheckedChanged += new System.EventHandler(this.rbalergia_CheckedChanged);
            // 
            // rbpadecimiento
            // 
            this.rbpadecimiento.AutoSize = true;
            this.rbpadecimiento.Enabled = false;
            this.rbpadecimiento.Location = new System.Drawing.Point(78, 80);
            this.rbpadecimiento.Name = "rbpadecimiento";
            this.rbpadecimiento.Size = new System.Drawing.Size(94, 17);
            this.rbpadecimiento.TabIndex = 2;
            this.rbpadecimiento.TabStop = true;
            this.rbpadecimiento.Text = "Padecimientos";
            this.rbpadecimiento.UseVisualStyleBackColor = true;
            this.rbpadecimiento.CheckedChanged += new System.EventHandler(this.rbpadecimiento_CheckedChanged);
            // 
            // btneliminar
            // 
            this.btneliminar.Enabled = false;
            this.btneliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneliminar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btneliminar.Location = new System.Drawing.Point(263, 62);
            this.btneliminar.Name = "btneliminar";
            this.btneliminar.Size = new System.Drawing.Size(107, 37);
            this.btneliminar.TabIndex = 4;
            this.btneliminar.Text = "Eliminar";
            this.btneliminar.UseVisualStyleBackColor = true;
            this.btneliminar.Click += new System.EventHandler(this.btneliminar_Click);
            // 
            // btnagregar
            // 
            this.btnagregar.Enabled = false;
            this.btnagregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnagregar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnagregar.Location = new System.Drawing.Point(263, 19);
            this.btnagregar.Name = "btnagregar";
            this.btnagregar.Size = new System.Drawing.Size(107, 37);
            this.btnagregar.TabIndex = 3;
            this.btnagregar.Text = "Agregar";
            this.btnagregar.UseVisualStyleBackColor = true;
            this.btnagregar.Click += new System.EventHandler(this.btnagregar_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtnombre);
            this.groupBox8.Controls.Add(this.label1);
            this.groupBox8.Controls.Add(this.label3);
            this.groupBox8.Controls.Add(this.label4);
            this.groupBox8.Controls.Add(this.txtcodigo);
            this.groupBox8.Controls.Add(this.label2);
            this.groupBox8.Controls.Add(this.label10);
            this.groupBox8.Controls.Add(this.combotipo);
            this.groupBox8.Controls.Add(this.combosangre);
            this.groupBox8.Controls.Add(this.combocarrera);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.dtfechanac);
            this.groupBox8.Location = new System.Drawing.Point(467, 13);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(381, 183);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Informacion ";
            // 
            // btn_salir
            // 
            this.btn_salir.BackColor = System.Drawing.Color.Transparent;
            this.btn_salir.FlatAppearance.BorderSize = 3;
            this.btn_salir.Location = new System.Drawing.Point(12, 577);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(120, 64);
            this.btn_salir.TabIndex = 12;
            this.btn_salir.Text = "Salir";
            this.btn_salir.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_salir.UseVisualStyleBackColor = false;
            this.btn_salir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // bteliminar
            // 
            this.bteliminar.BackColor = System.Drawing.Color.Transparent;
            this.bteliminar.FlatAppearance.BorderSize = 3;
            this.bteliminar.Location = new System.Drawing.Point(12, 507);
            this.bteliminar.Name = "bteliminar";
            this.bteliminar.Size = new System.Drawing.Size(120, 64);
            this.bteliminar.TabIndex = 8;
            this.bteliminar.Text = "Eliminar";
            this.bteliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.bteliminar.UseVisualStyleBackColor = false;
            this.bteliminar.Click += new System.EventHandler(this.bteliminar_Click);
            // 
            // btn_cambios
            // 
            this.btn_cambios.BackColor = System.Drawing.Color.Transparent;
            this.btn_cambios.FlatAppearance.BorderSize = 3;
            this.btn_cambios.Location = new System.Drawing.Point(12, 437);
            this.btn_cambios.Name = "btn_cambios";
            this.btn_cambios.Size = new System.Drawing.Size(120, 64);
            this.btn_cambios.TabIndex = 7;
            this.btn_cambios.Text = "Agregar";
            this.btn_cambios.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_cambios.UseVisualStyleBackColor = false;
            this.btn_cambios.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.Color.Transparent;
            this.btn_registrar.FlatAppearance.BorderSize = 3;
            this.btn_registrar.Location = new System.Drawing.Point(12, 437);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(120, 64);
            this.btn_registrar.TabIndex = 10;
            this.btn_registrar.Text = "Registrar";
            this.btn_registrar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.btnregistrar_Click);
            // 
            // btn_cancelar2
            // 
            this.btn_cancelar2.BackColor = System.Drawing.Color.Transparent;
            this.btn_cancelar2.FlatAppearance.BorderSize = 3;
            this.btn_cancelar2.Location = new System.Drawing.Point(12, 577);
            this.btn_cancelar2.Name = "btn_cancelar2";
            this.btn_cancelar2.Size = new System.Drawing.Size(120, 64);
            this.btn_cancelar2.TabIndex = 12;
            this.btn_cancelar2.Text = "Cancelar";
            this.btn_cancelar2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_cancelar2.UseVisualStyleBackColor = false;
            this.btn_cancelar2.Click += new System.EventHandler(this.btncancelar_Click);
            // 
            // btn_editar
            // 
            this.btn_editar.BackColor = System.Drawing.Color.Transparent;
            this.btn_editar.FlatAppearance.BorderSize = 3;
            this.btn_editar.Location = new System.Drawing.Point(12, 507);
            this.btn_editar.Name = "btn_editar";
            this.btn_editar.Size = new System.Drawing.Size(120, 64);
            this.btn_editar.TabIndex = 11;
            this.btn_editar.Text = "Editar";
            this.btn_editar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_editar.UseVisualStyleBackColor = false;
            this.btn_editar.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_nuevo
            // 
            this.btn_nuevo.BackColor = System.Drawing.Color.Transparent;
            this.btn_nuevo.FlatAppearance.BorderSize = 3;
            this.btn_nuevo.Location = new System.Drawing.Point(12, 437);
            this.btn_nuevo.Name = "btn_nuevo";
            this.btn_nuevo.Size = new System.Drawing.Size(120, 64);
            this.btn_nuevo.TabIndex = 11;
            this.btn_nuevo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_nuevo.UseVisualStyleBackColor = false;
            this.btn_nuevo.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.rtxtobservacion);
            this.groupBox9.Location = new System.Drawing.Point(160, 437);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(286, 203);
            this.groupBox9.TabIndex = 6;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Observación";
            // 
            // rtxtobservacion
            // 
            this.rtxtobservacion.Location = new System.Drawing.Point(6, 19);
            this.rtxtobservacion.Multiline = true;
            this.rtxtobservacion.Name = "rtxtobservacion";
            this.rtxtobservacion.ReadOnly = true;
            this.rtxtobservacion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.rtxtobservacion.Size = new System.Drawing.Size(274, 178);
            this.rtxtobservacion.TabIndex = 0;
            // 
            // FrmPacientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1281, 661);
            this.Controls.Add(this.bteliminar);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.btn_cambios);
            this.Controls.Add(this.btn_registrar);
            this.Controls.Add(this.btn_cancelar2);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.btn_editar);
            this.Controls.Add(this.btn_nuevo);
            this.Controls.Add(this.datagridx);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPacientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registro";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.Click += new System.EventHandler(this.FrmPacientes_Click);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridx)).EndInit();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datagrida)).EndInit();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datagridp)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox combotipo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbfemenino;
        private System.Windows.Forms.RadioButton rdbmasculino;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox combocarrera;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtaltura;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtpeso;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txttelefono;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtbusqueda;
        private System.Windows.Forms.DataGridView datagridx;
        private System.Windows.Forms.Button btn_nuevo;
        private System.Windows.Forms.DateTimePicker dtfechanac;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox combosangre;
        private System.Windows.Forms.ComboBox comboap;
        private System.Windows.Forms.TextBox txtcodigo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboetnia;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton rbpadecimiento;
        private System.Windows.Forms.RadioButton rbalergia;
        private System.Windows.Forms.Button btneliminar;
        private System.Windows.Forms.Button btnagregar;
        private System.Windows.Forms.DataGridView datagrida;
        private System.Windows.Forms.DataGridView datagridp;
        private System.Windows.Forms.DataGridViewTextBoxColumn alergia;
        private System.Windows.Forms.DataGridViewTextBoxColumn padecimiento;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.Button btn_editar;
        private System.Windows.Forms.Button btn_cancelar2;
        private System.Windows.Forms.Button btn_cambios;
        private System.Windows.Forms.Button bteliminar;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridViewTextBoxColumn codigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.TextBox txtemergencia;
        private System.Windows.Forms.TextBox rtxtobservacion;
    }
}